# Permission Set Comparator — LWC

Compare two or more Salesforce Permission Sets side-by-side across:
- **Object Permissions** (Read, Create, Edit, Delete, View All, Modify All)
- **Field-Level Permissions** (Read, Edit — per object)
- **Apex Class Access**
- **System Permissions**

---

## Files

```
permissionSetComparator/
├── classes/
│   ├── PermissionSetComparatorController.cls
│   └── PermissionSetComparatorController.cls-meta.xml
└── lwc/
    └── permissionSetComparator/
        ├── permissionSetComparator.html
        ├── permissionSetComparator.js
        ├── permissionSetComparator.css
        └── permissionSetComparator.js-meta.xml
```

---

## Deployment

### Option A — Salesforce CLI (SFDX)

```bash
# Authenticate to your org
sf org login web --alias myOrg

# Deploy
sf project deploy start \
  --source-dir permissionSetComparator \
  --target-org myOrg
```

### Option B — VS Code with Salesforce Extension Pack

1. Open this folder in VS Code.
2. Right-click `classes/PermissionSetComparatorController.cls` → **Deploy Source to Org**
3. Right-click `lwc/permissionSetComparator` folder → **Deploy Source to Org**

### Option C — Developer Console (manual)

1. Go to **Setup → Developer Console**
2. **File → New → Apex Class** → Name: `PermissionSetComparatorController` → paste the `.cls` content
3. For the LWC, use **VS Code** or CLI (Developer Console doesn't support LWC authoring)

---

## Add to a Lightning App Page

1. Go to **Setup → App Manager** → open/create a Lightning App
2. Or go to any **App Page** in Lightning App Builder
3. Drag **permissionSetComparator** from the custom components panel onto the page
4. Save and activate

---

## Required Permissions for running users

The user viewing this component needs:
- **View Setup and Configuration** — to query PermissionSet, ObjectPermissions, FieldPermissions
- **Apex Class Access** to `PermissionSetComparatorController`

Grant via a Permission Set assigned to admins or power users.

---

## How It Works

### Page 1 — Selection
- Loads all non-profile permission sets via `@wire`
- Search/filter by label or API name
- Select 2+ permission sets (shown as chips)
- Optionally filter by specific objects (to reduce field data)
- Click **Compare Permission Sets** → Apex callout

### Page 2 — Results

| Tab | Data Source |
|-----|------------|
| Object Permissions | `ObjectPermissions` SOQL |
| Field Permissions | `FieldPermissions` SOQL (grouped by object) |
| Apex Class Access | `SetupEntityAccess` WHERE `SetupEntityType = 'ApexClass'` |
| System Permissions | Dynamic SOQL on `PermissionSet` system perm fields |

- **Export CSV** button downloads a full cross-tab CSV
- **Back** returns to the selection page

---

## Customisation Tips

- **Add more system permission fields**: Extend the `systemPermFields` list in the Apex controller
- **Increase SOQL limits**: The component uses `LIMIT 500` on permission sets; adjust as needed
- **Highlight differences**: Add JS logic in `getObjectPermissions` to flag rows where cells differ
- **Tab visibility**: All 4 tabs are always shown; you can conditionally hide tabs based on your use case
